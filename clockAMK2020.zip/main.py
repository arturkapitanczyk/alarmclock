"""
COVID-19 - daily-briefing alarm clock
"""

#MIT License
#
#Copyright (c) [2020] [Artur Marek Kapitanczyk]
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all
#copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#SOFTWARE.
from flask import Flask
from flask import render_template
from flask import request
from flask import Markup
app = Flask(__name__)
import datetime
alarms = []
alarms_events = {}
notifications = []
image_markup = 'image_markup.jpg'
import pyttsx3
import sched
import time
import logging
import requests
from uk_covid19 import Cov19API
import json
logging.basicConfig(filename="alarm.log", level=logging.DEBUG)
tempdictionary = {}
engine = pyttsx3.init()
s = sched.scheduler(time.time, time.sleep)
tempdictionary["date_of_last_briefing_main"] = datetime.date(2020, 1, 1)
with open('config.json', 'r') as f:
    config_file = json.load(f)
API_key_dict = config_file["API-Keys"]

def check_if_future_date(difference_in_seconds: float):
    """Function used to check if the difference in seconds between 2 
    datetime.datetime objects is negative
    
    Description: 
        if 'difference in seconds' is negative, the function raises a ValueError.
        if 'difference in seconds' is positive, the function does nothing.
        
    Parameters:
        difference_in_seconds : float value of the time difference in seconds between two 
        datetime.datetime objects, 
        which represents (the time of the scheduled event) - (current local time)

    Returns: 
        None
   
    """
    if difference_in_seconds < 0:
        raise ValueError()

def check_if_same_name_used(name: str):
    """Function used to check if the label of the alarm to be scheduled is not 
    already in use
    
    Description: 
        the function iterates through the 'alarms' list of dictionaries
        for every dictionary, if the 'content' key returns a value the equal 
        to 'name', the function raises a ValueError.
        if the function has iterated through the entire 'alarms' list of 
        dictionaries, nothing more happens.
        
    Parameters:
        name: string value of the label entered into the HTML form when 
        scheduling an alarm

    Returns: 
        None
   
    """
    for earlier in alarms:
        if earlier["content"] == name:
            raise ValueError()

def get_weather_data_string() -> str:
    """Function used to get data from the https://openweathermap.org API and 
    return a formatted string response that can be returned into the HTML form 
    as a part of the UI
    
    Description: 
        first, the function combines the base_url, city_name and API key to 
        form a complete_url.
        
        second, the function uses the requests module to get back the data in 
        the form of a json object.
        
        third, the function converts the data into a dictionary, that can then 
        be read from.
        
        next, the function uses data from the dictionary to create a a formatted 
        string response that can be returned into the HTML form as a part of the UI, 
        also checking  if there have not been any errors in loading in data from the API. 
        If there have been errors, the function raises a ValueError with a 
        "weather" message - to later identify where the ValueError came from
        
        data regarding API key and city name is read from the config.json file
        
    Parameters:
        None

    Returns: 
        weather_output_string: str
   
    """
    weather_API_setup_dict = config_file["weather-API-setup"]
    base_url_weather = 'http://api.openweathermap.org/data/2.5/weather?'
    city_name_weather = weather_API_setup_dict["city"]
    api_key_weather = API_key_dict["weather"]
    complete_url_weather = base_url_weather + city_name_weather + api_key_weather
    
    response_weather = requests.get(complete_url_weather)
    x = response_weather.json()
    
    if x["cod"] != "404":
        y = x["main"]
        current_temp = int(y["temp"] - 273)
        current_pressure = y["pressure"]
        current_humidity = y["humidity"]
        z = x["weather"]
        weather_description = z[0]["description"]
        weather_output_string = "Overall, " + str(weather_description) + "<br /><br />" + ". The current temperature is: " + str(current_temp) + " degrees." + "<br /><br />" + "The current pressure is: " + str(current_pressure) + " pascals." + "<br /><br />" +  "The current humidity is: " + str(current_humidity) + " grams per kg of air."
        return weather_output_string
    else:
        raise ValueError("weather")
        
def get_news_data_string() -> str:
    """Function used to get data from the https://newsapi.org/ API and return 
    a formatted string response that can be returned into the HTML form as a 
    part of the UI
    
    Description: 
        First, the function combines the base_url, sorting filters, language 
        filters and API key to form a complete_url.
        Data is sorted by popularity (to include top news stories first) and 
        in English.
       
        Second, the function uses the requests module to get back the data in 
        the form of a json object.
        
        Third, the function converts the data into a dictionary, that can then 
        be read from.
        
        Next, the function uses data from the dictionary to create a 
        formatted string response that can be returned into the HTML form as a 
        part of the UI, also checking if there have not been any errors 
        in loading in data from the API. 
        If there have been errors, the function raises a ValueError with a 
        "news" message - to later identify where the ValueError came from.
        
        Data regarding API key is read from the config.json file
        
    Parameters:
        None

    Returns: 
        news_output_string: str
   
    """
    base_url_news = 'http://newsapi.org/v2/top-headlines?'
    sort_by_news = 'sortBy=popularity&'
    language_news = 'language=en&'
    oldest_date_news = 'from=' + str(datetime.date.today()) + '&'
    api_key_news = API_key_dict["news"]
    complete_url_news = base_url_news + sort_by_news + language_news + oldest_date_news + api_key_news

    response_news = requests.get(complete_url_news)
    x = response_news.json()
    if x['status'] == 'ok':
        y = x['articles']
        top1_news_art = y[0]
        top2_news_art = y[1]
        top3_news_art = y[2]
        news_output_string = "Top 3 news stories:<br /><br />"  + "1: " + top1_news_art['title'] + ": " + top1_news_art['url'] + "<br />" + "2: " + top2_news_art['title'] + ": " + top2_news_art['url'] + "<br />" + "3: " + top3_news_art['title'] + ": " + top3_news_art['url']
        return news_output_string
    else:
        raise ValueError("news")
        
def get_covid_data_string() -> str:
    """Function used to get data from the 
    https://publichealthengland.github.io/coronavirus-dashboard-api-python-sdk/ 
    API and return a formatted string response that can be returned into the HTML 
    form as a part of the UI
    
    Description: 
        first, the function defines the filter parameters for the API data from
        the config.json file.
        
        second, the function defines the data structure parameters for the API 
        data.
        
        third, the function reads the data and converts it into a dictionary, 
        that can then directly be read from.
        
        next, the function uses data from the dictionary to create a a formatted 
        string response that can be returned into the HTML form as a part of the UI, 
        also checking if there have not been any errors in loading in data from the API. 
        If there have been errors, the function raises a ValueError with a 
        "covid" message - to later identify where the ValueError came from
        
        data regarding API key and city name is read from the config.json file
        
    Parameters:
        None

    Returns: 
        covid_output_string: str
   
    """
    number_of_new_cases = -1
    covid_API_setup_dict = config_file["covid-API-setup"]
    england_only = [
        covid_API_setup_dict["areaType"],
        covid_API_setup_dict["areaName"]
    ]
    
    cases = {
        "date": "date",
        "areaCode": "areaCode",
        "newCasesByPublishDate": "newCasesByPublishDate"
    }
    
    api = Cov19API(filters=england_only, structure=cases)
    ###default area devon select from config file
    selected_area_code = covid_API_setup_dict["areaCode"]
    data = api.get_json()
    x = data['data']
    found_data = False
    for i in x:
        if (i['date'] == str(datetime.date.today())) and (i['areaCode'] == selected_area_code):
            number_of_new_cases = i['newCasesByPublishDate']
            found_data = True
    if found_data == False:
        raise ValueError("covid")
    covid_output_string = "The number of new local coronavirus cases today is: " + str(number_of_new_cases)
    #checking if output makes sense
    assert(number_of_new_cases() >= 0)
    return covid_output_string

def announcment(text: str):
    """The function that executes when the time of a scheduled alarm comes
    
    Description: 
        first the function uses the pyttsx3 (text to speech) module to speak the 
        'text' message as a alarm
        
        the second part of the function is about adding the given event with label 'text'
        into the notifications data structure, together with news, weather and covid infection
        rates information, depending on what the user selected when scheduling the alarm.
        
        this is done by creating a dictionary with 'text' as a value for the "title" key 
        and the returned API content strings merged together has a value for the 
        "content" key. the function checks for potential raised errors, handling them each
        in a separate, appropriate way. this dictionary is added to the HTML form
        
        finally, the function removes the alarm with label 'text' from the alarm data
        structure as well as the HTML form
        
    Parameters:
        text: string value of the label input by the user when scheduling an event

    Returns: 
        None
   
    """
    print("I am saying: " + text)
    try:
        engine.endLoop()
    except:
        logging.error('PyTTSx3 Endloop error. Program allowed to continue without adjustment.')
    engine.runAndWait()
    y = 0
    for i in alarms:
        if i["content"] == text:
            temp_dict_notif = {}
            temp_dict_notif["title"] = text
            if (alarms_events[text][1] is None) and (alarms_events[text][2] is None):
                temp_dict_notif["content"] = Markup(get_covid_data_string())
            if not(alarms_events[text][1] is None) and (alarms_events[text][2] is None):
                try:
                    temp_dict_notif["content"] = Markup(get_news_data_string() + "<br /><br />" + get_covid_data_string())
                except ValueError as error:
                    if str(error) == "news":
                        temp_dict_notif["content"] = Markup("News data unavailable in API for today" + "<br /><br />" + get_covid_data_string())
                    if str(error) == "covid":
                        temp_dict_notif["content"] = Markup(get_news_data_string() + "<br /><br />" + "Covid data unavailable in API for today")
                    logging.error('Missing API data. Program allowed to continue with adjustment.')
            if (alarms_events[text][1] is None) and not(alarms_events[text][2] is None):
                try:
                    temp_dict_notif["content"] = Markup(get_weather_data_string() + "<br /><br />" + get_covid_data_string())
                except ValueError as error:
                    if str(error) == "weather":
                        temp_dict_notif["content"] = Markup("Weather data unavailable in API for today" + "<br /><br />" + get_covid_data_string())
                    if str(error) == "covid":
                        temp_dict_notif["content"] = Markup(get_weather_data_string() + "<br /><br />" + "Covid data unavailable in API for today")
                    logging.error('Missing API data. Program allowed to continue with adjustment.')
            if not(alarms_events[text][1] is None) and not(alarms_events[text][2] is None):
                try:
                    temp_dict_notif["content"] = Markup(get_news_data_string() + "<br /><br />" + get_weather_data_string() + "<br /><br />" + get_covid_data_string())
                except ValueError as error:
                    if str(error) == "weather":
                        temp_dict_notif["content"] = Markup(get_news_data_string() + "<br /><br />" + "Weather data unavailable in API for today" + "<br /><br />" + get_covid_data_string())
                    if str(error) == "news":
                        temp_dict_notif["content"] = Markup("News data unavailable in API for today" + "<br /><br />" + get_weather_data_string() + "<br /><br />" + get_covid_data_string())
                    if str(error) == "covid":
                        temp_dict_notif["content"] = Markup(get_news_data_string() + "<br /><br />" + get_weather_data_string() + "<br /><br />" + "Covid data unavailable in API for today")
                    logging.error('Missing API data. Program allowed to continue with adjustment.')
            notifications.append(temp_dict_notif)
            alarms.pop(y)
            alarms_events.pop(text)
        y += 1

def daily_briefing(time_of_daily_briefing: datetime.datetime, date_of_last_briefing: datetime.date):
    """Function to run once a day at a given time to provide a daily briefing
    of news, weather and covid infection rates
    
    Description: 
        first, the function checks whether there was already a briefing today
        (by comparing current date to 'date_of_last_briefing'),
        as well as if the time during the current day is greater than the pre-set
        'time_of_daily_briefing' from the config file
        
        if a briefing has not happened on today's date and the current time is 
        later than the time at which the briefing is scheduled, then the function moves
        to its second part
        
        second part --> the function adds news, weather and covid infection
        rates information into the notification data structure, together with 
        a daily briefing + date title. the function checks for potential raised errors from API calls, 
        handling them each in a separate, appropriate way. data is added to the HTML form
        
    Parameters:
        time_of_daily_briefing: datetime.datetime object containing the time
        to the minute of when the briefing is to happen. information from config.json
        is used to construct this
        date_of_last_briefing: datetime.date object containing the time to the 
        date of when the last briefing happened (first of january 2020 by default
        to allow the process to start working). this is done to be able to make only 
        one briefing happen per day

    Returns: 
        None
   
    """
    if ((datetime.date.today() - date_of_last_briefing).total_seconds() > 0) and ((datetime.datetime.now() - time_of_daily_briefing).total_seconds()  > 0):
        tempdictionary["date_of_last_briefing_main"] = datetime.date.today()
        temp_dict_notif = {}
        temp_dict_notif["title"] = "Daily briefing: " + str(datetime.date.today())
        try:
            temp_dict_notif["content"] = Markup(get_news_data_string() + "<br /><br />" + get_weather_data_string() + "<br /><br />" + get_covid_data_string())
        except ValueError as error:
            if str(error) == "weather":
                temp_dict_notif["content"] = Markup(get_news_data_string() + "<br /><br />" + "Weather data unavailable in API for today" + "<br /><br />" + get_covid_data_string())
            if str(error) == "news":
                temp_dict_notif["content"] = Markup("News data unavailable in API for today" + "<br /><br />" + get_weather_data_string() + "<br /><br />" + get_covid_data_string())
            if str(error) == "covid":
                temp_dict_notif["content"] = Markup(get_news_data_string() + "<br /><br />" + get_weather_data_string() + "<br /><br />" + "Covid data unavailable in API for today")
            logging.error('Missing API data. Program allowed to continue with adjustment.')
        notifications.append(temp_dict_notif)
    
def remove_alarm():    
    """Function to be run in the refresh() function, that checks whether the button 
    to remove a specific alarm has been pressed that then removes that specific
    alarm from data structures and HTML if it has, cancelling the event
    
    Description: 
        first the function uses the request module to check if the button 
        to remove a specific alarm has been pressed. if it has, the label of
        the alarm is used to remove the alarm from the alarms and alarms_events
        data structures, as well as using the alarms_events dictionary to cancel
        the stored event that has been schedules
        
    Parameters:
        None

    Returns: 
        None
   
    """
    if not(request.args.get('alarm_item') is None):
        y = 0
        text_time = request.args.get('alarm_item')
        for i in alarms:    
            if i["title"] == text_time:
                alarms.pop(y)
                temp_title = i["content"]
                s.cancel(alarms_events[temp_title][0])
                alarms_events.pop(i["content"])               
            y += 1
            
def remove_notification():
    """Function to be run in the refresh() function, that checks whether the button 
    to remove a specific notification has been pressed that then removes that specific
    notification from data structures and HTML if it has
    
    Description: 
        first the function uses the request module to check if the button 
        to remove a specific notification has been pressed. if it has, the label of
        the alarm is used to remove the alarm from the notifications
        data structure and therefore the HTML
        
    Parameters:
        None

    Returns: 
        None
   
    """
    if not(request.args.get('notif') is None):
        z = 0
        text_title = request.args.get('notif')
        for i in notifications:    
            if i["title"] == text_title:
                notifications.pop(z)               
            z += 1

def schedule_alarm():
    """Function to be run in the refresh() function, that checks whether the 
    button to schedule a specific alarm has been pressed (submit button) and 
    then potentially schedules the function
    
    Description: 
        first, the function uses the request module to get information from the
        HTML template about: time of alarm, name of alarm, whether it should inform
        about weather and/or news
        
        second, the function uses the time input into the HTML form to calculate 
        the difference in seconds from the moment this function is run to when
        the scheduled event is to be executed. the function uses the check_if_future_date()
        function to check if this difference is not negative, then if a error
        is not raised it schedules the events, storing it in a dictionary data
        structure for later reference as well as adding it to the HTML data structures
        
    Parameters:
        None

    Returns: 
        None
   
    """
    time_of_alarm = request.args.get('alarm')
    name_of_alarm = request.args.get('two')
    news_boolean = request.args.get('news')
    weather_boolean = request.args.get('weather')
        
    current_time = datetime.datetime.now()
    #conversion of HTML datetime-local to a datetime.datetime python object
    later_time = datetime.datetime.strptime(time_of_alarm, '%Y-%m-%dT%H:%M')
   
    difference = later_time - current_time

    difference_in_seconds = difference.total_seconds()
    try:
        check_if_future_date(difference_in_seconds)
    except ValueError:
        print("kekw u entered past date")
        return render_template('template.html', image = image_markup, alarms = alarms, notifications = notifications)
        
        
    temp_dict_alarm = {}
    temp_dict_alarm["title"] = time_of_alarm
    temp_dict_alarm["content"] = name_of_alarm
    
    news_boolean_text = news_boolean
    weather_boolean_text = weather_boolean
    
    if news_boolean is None:
        news_boolean_text = " not news"
    if weather_boolean is None:
        weather_boolean_text = " not weather"
        
    logging.info("Event with label: " + name_of_alarm + ", scheduled for: " + time_of_alarm + ". " + news_boolean_text + weather_boolean_text)
    
    alarms.append(temp_dict_alarm)
        
    alarms_events[name_of_alarm] = [s.enter(difference_in_seconds, 1, announcment, (name_of_alarm,)), news_boolean, weather_boolean]

@app.route('/')
def load():
    """Function to load in the basic HTML form first
    
    Description: 
        renders the HTML template
        
    Parameters:
        None

    Returns: 
        HTML template
   
    """
    return render_template('template.html', image = image_markup, alarms = alarms, notifications = notifications)

@app.route('/index')
def refresh():
    """Function run every minute to refresh the HTML form and push scheduled events to execute
    
    Description: 
        Core function that coordinates all other functions to provide service to
        the user. It is run every minute due to the HTML form
        
    Parameters:
        None

    Returns: 
        HTML template
   
    """
    try:
        check_if_same_name_used(request.args.get('two'))
    except ValueError:
        logging.error('Wrong user input. Date to be scheduled is before current time.')
        return render_template('template.html', image = image_markup, alarms = alarms, notifications = notifications)
    
    s.run(blocking = False)
    
    daily_briefing_precise_time_dict = config_file["daily-briefing-precise-time"]
    time_of_daily_briefing = datetime.datetime(datetime.datetime.now().year, datetime.datetime.now().month, datetime.datetime.now().day, int(daily_briefing_precise_time_dict["hour"]), int(daily_briefing_precise_time_dict["min"]))
    daily_briefing(time_of_daily_briefing, tempdictionary["date_of_last_briefing_main"])
    
    remove_alarm()

    remove_notification()
    
    if request.args.get('alarm') is None:
        return render_template('template.html', image = image_markup, alarms = alarms, notifications = notifications)
    else:
        schedule_alarm()
        
    return render_template('template.html', image = image_markup, alarms = alarms, notifications = notifications)


if __name__ == '__main__':
    app.run()
